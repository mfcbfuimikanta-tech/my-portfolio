# Data provenance

`sample/` contains synthetic, randomly generated data for a reproducible coding demonstration. No real borrowers or businesses are represented.

The **original** files (`borrower_profiles.csv` and `loan_applications(1).csv`) are **not included** here because they were not available during packaging. To reproduce the original study, place them locally in `data/original/` and run the commands in the root README. `data/original/` is Git-ignored by default. Confirm permission and remove sensitive identifiers before publishing source files.

Sample columns:
- borrower_profiles: `borrower_id`, `credit_score`, `debt_to_income_ratio` (percentage), `employment_status`, `years_employed`, `annual_income`
- loan_applications: `loan_id`, `borrower_id`, `loan_amount`, `loan_purpose`, `term_months`, `interest_rate`, `defaulted` (0 or 1)
