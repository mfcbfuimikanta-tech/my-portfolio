-- LOAN DEFAULT RISK ANALYSIS | MySQL 8+
-- This code is designed for the column names in data/sample/*.csv.
-- If your original CSV names differ, update references accordingly.
-- Load both CSVs into borrower_profiles and loan_applications before running.

-- 1) Verify source data and the many-to-one join
SELECT COUNT(*) AS loans, COUNT(DISTINCT loan_id) AS unique_loans
FROM loan_applications;
SELECT COUNT(*) AS borrowers, COUNT(DISTINCT borrower_id) AS unique_borrowers
FROM borrower_profiles;
SELECT COUNT(*) AS unmatched_loans
FROM loan_applications AS l
LEFT JOIN borrower_profiles AS b ON l.borrower_id=b.borrower_id
WHERE b.borrower_id IS NULL;

-- 2) Overall default rate: mean of a 0/1 flag * 100
SELECT COUNT(*) AS total_loans,
       SUM(defaulted) AS total_defaults,
       ROUND(AVG(defaulted)*100,2) AS default_rate_pct
FROM loan_applications;

-- 3) Credit score segmentation
SELECT CASE
           WHEN b.credit_score < 520 THEN 'Below 520'
           WHEN b.credit_score < 600 THEN '520-599'
           WHEN b.credit_score < 650 THEN '600-649'
           WHEN b.credit_score < 700 THEN '650-699'
           WHEN b.credit_score < 750 THEN '700-749'
           ELSE '750+'
       END AS credit_bucket,
       COUNT(*) AS loans, SUM(l.defaulted) AS defaults,
       ROUND(AVG(l.defaulted)*100,2) AS default_rate_pct
FROM loan_applications AS l
JOIN borrower_profiles AS b ON l.borrower_id=b.borrower_id
GROUP BY credit_bucket
ORDER BY MIN(b.credit_score);

-- 4) DTI: assumes debt_to_income_ratio stored as percentage (e.g., 35 for 35%)
-- If it is stored as a proportion (e.g., 0.35), use 0.40 rather than 40.
SELECT CASE WHEN b.debt_to_income_ratio >= 40 THEN '40% or higher'
            ELSE 'Below 40%' END AS dti_segment,
       COUNT(*) AS loans, SUM(l.defaulted) AS defaults,
       ROUND(AVG(l.defaulted)*100,2) AS default_rate_pct
FROM loan_applications AS l
JOIN borrower_profiles AS b ON l.borrower_id=b.borrower_id
GROUP BY dti_segment;

-- 5) Loan purpose analysis
SELECT loan_purpose, COUNT(*) AS loans, SUM(defaulted) AS defaults,
       ROUND(AVG(defaulted)*100,2) AS default_rate_pct
FROM loan_applications
GROUP BY loan_purpose
ORDER BY default_rate_pct DESC;

-- 6) Compare average loan amounts, not proof of statistical significance
SELECT CASE WHEN defaulted=1 THEN 'Default' ELSE 'No default' END AS outcome,
       COUNT(*) AS loans, ROUND(AVG(loan_amount),2) AS avg_amount
FROM loan_applications
GROUP BY defaulted;

-- 7) Employment status and years employed
SELECT b.employment_status,
       COUNT(*) AS loans, SUM(l.defaulted) AS defaults,
       ROUND(AVG(l.defaulted)*100,2) AS default_rate_pct
FROM loan_applications AS l
JOIN borrower_profiles AS b ON l.borrower_id=b.borrower_id
GROUP BY b.employment_status ORDER BY default_rate_pct DESC;

SELECT CASE WHEN b.years_employed < 2 THEN 'Under 2 years' ELSE '2+ years' END AS tenure,
       COUNT(*) AS loans, SUM(l.defaulted) AS defaults,
       ROUND(AVG(l.defaulted)*100,2) AS default_rate_pct
FROM loan_applications AS l
JOIN borrower_profiles AS b ON l.borrower_id=b.borrower_id
GROUP BY tenure ORDER BY tenure DESC;
