-- Optional MySQL 8+ table definitions for the included SYNTHETIC sample CSVs.
-- Import with MySQL Workbench's "Table Data Import Wizard" after creating tables.
-- These are demonstration schemas, not guaranteed to match original dataset headers.

CREATE DATABASE IF NOT EXISTS loan_risk_portfolio;
USE loan_risk_portfolio;

CREATE TABLE IF NOT EXISTS borrower_profiles (
  borrower_id VARCHAR(20) PRIMARY KEY,
  credit_score INT,
  debt_to_income_ratio DECIMAL(6,2),
  employment_status VARCHAR(50),
  years_employed DECIMAL(6,2),
  annual_income INT
);

CREATE TABLE IF NOT EXISTS loan_applications (
  loan_id VARCHAR(20) PRIMARY KEY,
  borrower_id VARCHAR(20) NOT NULL,
  loan_amount DECIMAL(12,2),
  loan_purpose VARCHAR(80),
  term_months INT,
  interest_rate DECIMAL(6,2),
  defaulted TINYINT,
  FOREIGN KEY (borrower_id) REFERENCES borrower_profiles(borrower_id)
);

-- Import borrower_profiles.csv first, loan_applications.csv second.
-- Validate import counts: 320 borrowers and 460 loan applications for the sample.
