# Loan Default Risk Analysis

**A data analytics portfolio project** | Python (Pandas) · SQL · Interactive dashboard

> **Data transparency:** This repository contains **synthetic sample data** so all code and the dashboard can be run and reviewed. The original 500-borrower/601-loan files from an earlier exercise were not available when this package was created. Results from that earlier exercise are documented separately and **are not outputs from these synthetic CSVs**.

## Business challenge
A lending business wants to understand which features are associated with loan defaults. The analysis asks:
1. How does default rate vary across credit score groups?
2. Is debt-to-income (DTI) associated with loan defaults? What happens above/below 40%?
3. Which loan purposes have higher observed default rates, and do loan amounts differ by default outcome?
4. How do employment status and tenure compare, especially under 2 years?

## Project deliverables
| Deliverable | Location |
|---|---|
| Executed step-by-step Jupyter notebook | [`notebooks/loan_default_analysis.ipynb`](notebooks/loan_default_analysis.ipynb) |
| Full reproducible Pandas analysis | [`src/analyze.py`](src/analyze.py) |
| MySQL schema & queries | [`sql/schema_mysql.sql`](sql/schema_mysql.sql) and [`sql/loan_default_mysql.sql`](sql/loan_default_mysql.sql) |
| Offline interactive demo dashboard | [`dashboard/demo_dashboard.html`](dashboard/demo_dashboard.html) |
| Generated demo summary tables | [`reports/demo/`](reports/demo/) |
| Previous original dataset findings | [`docs/original_results_previous_run.md`](docs/original_results_previous_run.md) |
| GitHub upload instructions | [`docs/GITHUB_UPLOAD_GUIDE.md`](docs/GITHUB_UPLOAD_GUIDE.md) |
| Power BI build guide | [`powerbi/README.md`](powerbi/README.md) |

## Dashboard preview — SYNTHETIC SAMPLE

![Default rate by credit score on synthetic data](images/demo/credit_by_score.png)

![Default rate by DTI segment on synthetic data](images/demo/default_by_dti.png)

The self-contained HTML dashboard provides hover details and four interactive charts. Open [`dashboard/demo_dashboard.html`](dashboard/demo_dashboard.html) locally in your browser.

## Demonstration metrics — synthetic sample

Running the reproducible synthetic example yields **78 defaults across 460 loans (16.96%)**. These are demonstration figures, unrelated to the original dataset.

## Main findings — prior analysis of ORIGINAL dataset (requires independent rerun)

From the *previously recorded analysis*, **146 / 601 loans (24.29%)** defaulted. Those previously recorded results suggested lower default rates for higher credit-score ranges, higher rates above 40% DTI (31.52% vs 12.88%), and higher rates for employment under 2 years (34.52% vs 22.63%). A more complete table, caveats and revalidation instructions are in [the original-analysis findings file](docs/original_results_previous_run.md).

**These numbers were not derived from the synthetic example in this repository.** The full original data is needed to rerun and verify them.

## Reproduce the demo

Requirements: Python 3.10+.

```bash
python -m pip install -r requirements.txt
python src/analyze.py
python src/build_dashboard.py
```

Outputs are refreshed in `reports/demo`, `images/demo`, and `dashboard/demo_dashboard.html`.

## Run on the original CSVs

Save your original datasets in `data/original/` (excluded from Git by `.gitignore`), then run:

```bash
python src/analyze.py --borrowers data/original/borrower_profiles.csv --loans "data/original/loan_applications(1).csv" --out reports/original --images images/original --label "Original loan dataset"
python src/build_dashboard.py --reports reports/original --out dashboard/original_dashboard.html
```

If your original column names differ, `src/analyze.py` checks required fields and lists missing columns. Edit its `ALIASES` mapping to match your CSV headers. If DTI is stored as a fraction (0.40) instead of percent (40), the Python script detects the overall format, but verify it with your data dictionary.

## Approach and analytical quality
1. **Inspect** shapes, column names, types, nulls and identifier uniqueness.
2. **Validate** the `borrower_id` relationship: loans can be many-to-one with borrower profiles; unmatched IDs are reported.
3. **Calculate** default = count of defaulted loans / all loans; always include sample sizes for segments.
4. **Compare** credit score ranges, DTI bands, loan purposes and employment profiles.
5. **Communicate** patterns, uncertainty and limitations; 40% DTI is exploratory, *not* a recommended production approval cutoff.

## What this project demonstrates
- SQL `JOIN`, `GROUP BY`, `CASE`, aggregate functions and data-quality checks
- Pandas `read_csv`, `merge`, `groupby`, `cut`, missing-value checks and visualization
- Clear business questions, documented metrics, a reproducible workflow, and an interactive dashboard

## Limitations and ethics
The synthetic demo is for education only. Observed default rates cannot establish causation, and this project is **not** a calibrated credit risk scoring model. Any real-world lending rule needs independent validation, fairness testing and legal review. Avoid sharing real personal or financial information publicly without permission.

**Project type:** Educational / independent portfolio case study. Not employment experience.
