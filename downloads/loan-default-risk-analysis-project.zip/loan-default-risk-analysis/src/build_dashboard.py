"""Create an offline interactive HTML dashboard from generated report CSVs."""
import argparse
import json
from pathlib import Path
import pandas as pd
import plotly.express as px

def build(report_dir:Path,output_html:Path):
    summary=json.loads((report_dir/'summary.json').read_text(encoding='utf-8'))
    defs=[
        ('credit_score','credit_bucket','Credit score bands'),
        ('dti','dti_group','DTI segments'),
        ('loan_purpose','loan_purpose','Purpose of loan'),
        ('employment_tenure','employment_tenure','Employment tenure')]
    sections=[]
    for i,(file,col,title) in enumerate(defs):
        df=pd.read_csv(report_dir/f'{file}.csv')
        fig=px.bar(df,x=col,y='default_rate_pct',hover_data=['loans','defaults'],title=title,
            labels={'default_rate_pct':'Default rate (%)',col:''})
        fig.update_traces(text=df['default_rate_pct'].round(1).astype(str)+'%',textposition='outside')
        fig.update_layout(template='plotly_white',height=390,margin=dict(l=28,r=16,t=65,b=85),showlegend=False)
        fig.update_yaxes(rangemode='tozero',range=[0,max(10,df['default_rate_pct'].max()*1.23)])
        sections.append(fig.to_html(full_html=False,include_plotlyjs=(i==0),config={'displayModeBar':False}))
    data_label=summary['data_label']
    default_rate=summary['default_rate_pct']
    original_notice='This page is a synthetic-data demonstration. It is NOT a visualization of the original 601-loan dataset.' if 'synthetic' in data_label.lower() else 'Source: '+data_label+'. Check sharing rights before publishing any reports.'
    dashboard=f"""<!DOCTYPE html><html lang="en"><head><meta charset="utf-8"/><meta name="viewport" content="width=device-width,initial-scale=1"/>
<title>Loan Default Risk | {data_label}</title>
<style>body{{font-family:system-ui,-apple-system,Segoe UI,Roboto,sans-serif;margin:0;background:#f4f7fb;color:#17324d}}.top{{background:#103452;color:white;padding:42px max(22px,calc((100vw - 1100px)/2));}}.top h1{{font-size:clamp(26px,4vw,38px);margin:0 0 10px}}.top p{{opacity:.85;max-width:900px;line-height:1.6}}main{{max-width:1100px;margin:28px auto;padding:0 20px 40px}}.notice{{border-left:5px solid #e6a931;padding:14px 18px;background:#fff9e9;border-radius:6px;margin-bottom:22px}}.cards{{display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:16px;margin-bottom:18px}}.kpi{{background:white;border:1px solid #e7ebf0;border-radius:12px;padding:23px;box-shadow:0 3px 10px #0b253208}}.kpi strong{{font-size:31px;display:block;padding-top:10px;color:#0b4d73}}.kpi span{{color:#607486;font-size:14px}}.grid{{display:grid;grid-template-columns:repeat(auto-fit,minmax(440px,1fr));gap:18px}}.chart{{background:white;border:1px solid #e7ebf0;border-radius:12px;overflow:hidden}}footer{{font-size:13px;color:#61788a;line-height:1.7;margin:26px 0}}@media(max-width:500px){{.grid{{grid-template-columns:1fr}}}}</style></head>
<body><header class="top"><h1>Loan Default Risk Analysis</h1><p>Interactive descriptive dashboard · {data_label}</p></header>
<main><div class="notice"><strong>Dataset disclosure</strong><div>{original_notice}</div></div>
<section class="cards"><div class="kpi"><span>Total applications</span><strong>{summary['applications_rows']:,}</strong></div><div class="kpi"><span>Defaulted loans</span><strong>{summary['defaults']:,}</strong></div><div class="kpi"><span>Default rate</span><strong>{default_rate:.2f}%</strong></div><div class="kpi"><span>Borrower records</span><strong>{summary['borrowers_rows']:,}</strong></div></section>
<section class="grid">{''.join('<div class="chart">'+s+'</div>' for s in sections)}</section>
<footer>Hover over charts for sample sizes and defaults. Historical associations are not causal or proof that any approval cutoff is effective or fair. Includes credit score, DTI, purpose and employment tenure segmentation.</footer></main></body></html>"""
    output_html.parent.mkdir(parents=True,exist_ok=True)
    output_html.write_text(dashboard,encoding='utf-8')
    print(f'Wrote interactive offline dashboard: {output_html}')

if __name__=='__main__':
    p=argparse.ArgumentParser()
    p.add_argument('--reports',type=Path,default=Path('reports/demo'))
    p.add_argument('--out',type=Path,default=Path('dashboard/demo_dashboard.html'))
    a=p.parse_args()
    build(a.reports,a.out)
