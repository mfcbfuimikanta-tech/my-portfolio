"""Portfolio analysis: reads two related CSVs and exports descriptive summaries.

This script intentionally does *not* train a credit approval model or prescribe lending decisions.
"""
from __future__ import annotations
import argparse
import json
import re
from pathlib import Path

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ALIASES = {
    'borrower_id': ['borrower_id', 'customer_id'],
    'loan_id': ['loan_id', 'application_id'],
    'defaulted': ['defaulted', 'is_default', 'default_flag', 'loan_default'],
    'credit_score': ['credit_score', 'fico_score', 'fico'],
    'debt_to_income_ratio': ['debt_to_income_ratio', 'dti', 'dti_ratio', 'debt_to_income', 'debt_income_ratio'],
    'loan_amount': ['loan_amount', 'amount', 'principal', 'requested_loan_amount'],
    'loan_purpose': ['loan_purpose', 'purpose', 'loan_type'],
    'employment_status': ['employment_status', 'employment_type', 'job_status'],
    'years_employed': ['years_employed', 'employment_years', 'years_of_employment', 'employment_length', 'employment_duration'],
}

def normalize_names(df):
    df = df.copy()
    df.columns = [re.sub(r'[^a-z0-9]+','_',str(c).strip().lower()).strip('_') for c in df.columns]
    renames = {}
    for canonical, possibilities in ALIASES.items():
        if canonical not in df.columns:
            found = next((name for name in possibilities if name in df.columns),None)
            if found: renames[found] = canonical
    return df.rename(columns=renames)

def parse_numeric(s):
    return pd.to_numeric(s.astype('string').str.replace(',','',regex=False).str.replace('%','',regex=False).str.replace('$','',regex=False).str.strip(), errors='coerce')

def parse_years(s):
    if pd.api.types.is_numeric_dtype(s):
        return pd.to_numeric(s, errors='coerce')
    as_text=s.astype('string').str.lower().str.strip()
    result=pd.to_numeric(as_text.str.extract(r'(\d+(?:\.\d+)?)',expand=False),errors='coerce')
    result.loc[as_text.str.contains(r'less than|<\s*1',na=False)] = 0.5
    result.loc[as_text.str.contains(r'^10\+',regex=True,na=False)] = 10
    return result

def read_join(borrowers_file:Path,loans_file:Path):
    b=normalize_names(pd.read_csv(borrowers_file))
    l=normalize_names(pd.read_csv(loans_file))
    required_b=['borrower_id','credit_score','debt_to_income_ratio','employment_status','years_employed']
    required_l=['loan_id','borrower_id','loan_amount','loan_purpose','defaulted']
    for name,cols,df in [('borrower',required_b,b),('loan',required_l,l)]:
        missing=[col for col in cols if col not in df.columns]
        if missing: raise ValueError(f'{name} file missing columns {missing}. Available: {list(df.columns)}. Update ALIASES in src/analyze.py if needed.')
    if b['borrower_id'].isna().any() or l['borrower_id'].isna().any():
        raise ValueError('Missing borrower identifiers. Inspect these rows before joining.')
    if b['borrower_id'].duplicated().any():
        raise ValueError('Duplicate borrower IDs in profiles. A many-to-one join would inflate loan counts.')
    if l['loan_id'].isna().any() or l['loan_id'].duplicated().any():
        raise ValueError('Duplicate/missing loan IDs. Inspect your source data.')
    # Normalized to strings to avoid accidental int/string mismatch
    b['borrower_id']=b['borrower_id'].astype('string').str.strip()
    l['borrower_id']=l['borrower_id'].astype('string').str.strip()
    joined=l.merge(b,on='borrower_id',how='left',validate='many_to_one',indicator=True)
    unmatched=int((joined['_merge']!='both').sum())
    if unmatched: raise ValueError(f'{unmatched} loan(s) have no matched borrower. Fix keys before computing metrics.')
    joined=joined.drop(columns=['_merge'])
    if len(joined)!=len(l):raise RuntimeError('Join changed the number of applications')
    joined['defaulted']=parse_numeric(joined['defaulted'])
    if joined['defaulted'].isna().any() or not joined['defaulted'].isin([0,1]).all():
        raise ValueError("defaulted must contain only 0/1 and no nulls")
    joined['defaulted']=joined['defaulted'].astype(int)
    joined['credit_score']=parse_numeric(joined['credit_score'])
    joined['loan_amount']=parse_numeric(joined['loan_amount'])
    joined['years_employed']=parse_years(joined['years_employed'])
    joined['dti_percent']=parse_numeric(joined['debt_to_income_ratio'])
    # DTI is sometimes encoded 0.35 rather than 35: use a documented data-wide test.
    positive=joined['dti_percent'].dropna()
    if len(positive) and positive.quantile(0.95)<=1.0:
        joined['dti_percent']=joined['dti_percent']*100
    return b,l,joined

def grouped_rate(df,group_col):
    out=(df.groupby(group_col,dropna=False,observed=True)['defaulted']
           .agg(loans='count',defaults='sum',default_rate='mean').reset_index())
    out['default_rate_pct']=(out.pop('default_rate')*100).round(2)
    return out

def analyze(borrowers_file:Path,loans_file:Path,out_dir:Path,img_dir:Path,label='Synthetic demo'):
    out_dir.mkdir(parents=True,exist_ok=True)
    img_dir.mkdir(parents=True,exist_ok=True)
    borrowers, loans, data=read_join(borrowers_file,loans_file)
    n=int(len(data)); defaults=int(data['defaulted'].sum()); overall=round(defaults/n*100,2)
    credit_bins=[-np.inf,519,599,649,699,749,np.inf]
    credit_labels=['Below 520','520–599','600–649','650–699','700–749','750+']
    data['credit_bucket']=pd.cut(data['credit_score'],bins=credit_bins,labels=credit_labels,include_lowest=True)
    score=grouped_rate(data,'credit_bucket')
    score=score[score['loans']>0]
    data['dti_group']=np.where(data['dti_percent'].isna(),'Missing DTI',np.where(data['dti_percent'].ge(40).fillna(False),'40% or higher','Below 40%'))
    dti=grouped_rate(data,'dti_group')
    purpose=grouped_rate(data,'loan_purpose').sort_values('default_rate_pct',ascending=False)
    status=grouped_rate(data,'employment_status').sort_values('default_rate_pct',ascending=False)
    data['employment_tenure']=np.where(data['years_employed'].isna(),'Unknown',np.where(data['years_employed'].lt(2).fillna(False),'Under 2 years','2+ years'))
    tenure=grouped_rate(data,'employment_tenure')
    amounts=(data.groupby('defaulted')['loan_amount'].agg(loans='count',mean_loan_amount='mean').reset_index())
    amounts['outcome']=amounts['defaulted'].map({0:'No default',1:'Default'})
    amounts['mean_loan_amount']=amounts['mean_loan_amount'].round(2)
    tables={'credit_score':score,'dti':dti,'loan_purpose':purpose,'employment_status':status,'employment_tenure':tenure,'loan_amount':amounts}
    for name,t in tables.items():t.to_csv(out_dir/f'{name}.csv',index=False)
    summary={'data_label':label,'borrowers_rows':len(borrowers),'applications_rows':n,'defaults':defaults,'default_rate_pct':overall,
             'join_key':'borrower_id','dti_cutoff_for_exploration':40,'data_warning':'Descriptive associations; not a predictive or fair lending approval policy.'}
    (out_dir/'summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
    report=f"""# Automated Loan Default Analysis — {label}

    **Dataset label:** {label}  
    **Borrower records:** {len(borrowers):,}  
    **Loan applications:** {n:,}  
    **Defaults:** {defaults:,}  
    **Overall default rate:** **{overall:.2f}%**

    The analysis joined loan applications to borrower profiles on `borrower_id`, with a many-to-one integrity check.

    ## Findings by segment
    See the generated CSV summaries for rates and denominators:
    - `credit_score.csv`
    - `dti.csv`
    - `loan_purpose.csv`
    - `employment_status.csv`
    - `employment_tenure.csv`
    - `loan_amount.csv`

    ## Interpretation
    Segment-level default rates are historical sample associations, not causal estimates. Small segments may have unstable rates. The 40% DTI split is an illustration for exploration, **not** a validated loan-approval rule.
    """
    (out_dir/'analysis_summary.md').write_text('\n'.join(line[8:] if line.startswith('        ') else line for line in report.splitlines())+'\n',encoding='utf-8')
    chart_data=[('Default rate by credit score',score,'credit_bucket','credit_by_score.png'),
                ('Default rate by DTI group',dti,'dti_group','default_by_dti.png'),
                ('Default rate by loan purpose',purpose,'loan_purpose','default_by_purpose.png'),
                ('Default rate by employment tenure',tenure,'employment_tenure','default_by_tenure.png')]
    for title,frame,col,filename in chart_data:
        view=frame[frame['loans']>0].copy()
        fig,ax=plt.subplots(figsize=(8,4.3))
        bars=ax.bar(view[col].astype(str),view['default_rate_pct'])
        ax.set_title(title+' — '+label,fontsize=11)
        ax.set_ylabel('Default rate (%)')
        ax.set_ylim(0,max(10,float(view['default_rate_pct'].max())*1.23))
        ax.tick_params(axis='x',labelrotation=27)
        for bar,(_,rec) in zip(bars,view.iterrows()):
            ax.annotate(f"{rec['default_rate_pct']:.1f}%\nn={int(rec['loans'])}",
                (bar.get_x()+bar.get_width()/2,bar.get_height()),xytext=(0,3),textcoords='offset points',ha='center',va='bottom',fontsize=8)
        fig.tight_layout()
        fig.savefig(img_dir/filename,dpi=145)
        plt.close(fig)
    print(f"{label}: {defaults}/{n} defaults ({overall:.2f}%), generated reports in {out_dir}")
    return summary,tables

if __name__=='__main__':
    parser=argparse.ArgumentParser(description='Loan Default Risk portfolio analysis')
    parser.add_argument('--borrowers',type=Path,default=Path('data/sample/borrower_profiles.csv'))
    parser.add_argument('--loans',type=Path,default=Path('data/sample/loan_applications.csv'))
    parser.add_argument('--out',type=Path,default=Path('reports/demo'))
    parser.add_argument('--images',type=Path,default=Path('images/demo'))
    parser.add_argument('--label',default='Synthetic demo')
    args=parser.parse_args()
    analyze(args.borrowers,args.loans,args.out,args.images,args.label)
