# Previously reported findings — original loan dataset

**Evidence status:** These figures were recorded in an earlier analysis of the user's original files. The original raw CSVs were not available when this GitHub package was assembled, so the figures below have **not been independently re-run or checked** as part of this release. Do not confuse them with the clearly marked synthetic demo metrics.

Dataset described in that earlier run:
- `borrower_profiles.csv`: **500 rows**
- `loan_applications(1).csv`: **601 rows**
- Join key: `borrower_id`; joined result was 601 rows
- Earlier checks reported no missing values or duplicate identifier problems

| Question | Earlier reported result |
|---|---|
| Overall default rate | 146 out of 601 loans, **24.29%** |
| Credit 520–599 | **49.14%** default rate |
| Credit 600–649 | **29.03%** default rate |
| Credit 650–699 | **28.00%** default rate |
| Credit 700–749 | **16.28%** default rate |
| Credit 750+ | **11.69%** default rate |
| DTI at least 40% | **31.52%** default rate |
| DTI below 40% | **12.88%** default rate |
| Wedding loans | **32.14%** default rate |
| Home Improvement | **28.57%** default rate |
| Auto Loan | **27.12%** default rate |
| Mean loan amount — defaulted | **$22,570.55** |
| Mean loan amount — not defaulted | **$22,012.75** |
| Employment under 2 years | **34.52%** default rate |
| Employment 2 years or more | **22.63%** default rate |

## Business interpretation

**Potential signals:** Credit score, DTI, and years employed appear associated with loan outcomes in this historical sample. A DTI of 40% may be useful as an **exploratory segment**, but it is *not* a validated approval cutoff. Lending rules require validation on held-out or later data, fairness/legal review, and a business assessment of false rejections and losses.

**Loan amount:** Earlier analysis reported only a small difference in means (~$558); no statistical test or confidence interval was available when preparing this package, so avoid claiming the difference is significant or insignificant.

## How to verify

After adding the original CSVs, run `python src/analyze.py --borrowers data/original/borrower_profiles.csv --loans 'data/original/loan_applications(1).csv' --out reports/original --images images/original --label 'Original loan data'`. Compare the generated tables against these reported figures and investigate discrepancies (e.g., DTI units, null rows, filters, duplicate IDs, or grouping assumptions).
