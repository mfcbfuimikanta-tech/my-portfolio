# Upload this project to GitHub

1. Extract the ZIP archive.
2. Sign in at https://github.com and choose **New repository**.
3. Name it `loan-default-risk-analysis`.
4. Optionally add this description: `End-to-end loan default risk analysis using Python (Pandas), SQL, and an interactive HTML dashboard.`
5. Select **Public** if you want recruiters to access it. Do **not** ask GitHub to create a README: this project already includes one.
6. Choose **Add file → Upload files** and upload **the contents** of the extracted `loan-default-risk-analysis` folder, preserving subfolders. (For larger projects, use Git locally.)
7. Commit. Your README will render on the repository homepage.
8. Link the repo from your CV and LinkedIn.

## Command-line alternative
```bash
git init
git add .
git commit -m "Publish loan default risk analysis portfolio project"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/loan-default-risk-analysis.git
git push -u origin main
```

## Important
- The committed CSVs are **synthetic**. They are clearly labeled in README.
- The earlier **original** analysis metrics are in `docs/original_results_previous_run.md`, not represented as outputs of the synthetic dataset.
- Only publish original loan files if you have permission and have removed sensitive details.
- To create true original-data charts and reports, replace input paths and rerun the scripts locally.
