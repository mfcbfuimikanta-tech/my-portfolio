# Automated Loan Default Analysis — Synthetic demo

    **Dataset label:** Synthetic demo  
    **Borrower records:** 320  
    **Loan applications:** 460  
    **Defaults:** 78  
    **Overall default rate:** **16.96%**

    The analysis joined loan applications to borrower profiles on `borrower_id`, with a many-to-one integrity check.

    ## Findings by segment
    See the generated CSV summaries for rates and denominators:
    - `credit_score.csv`
    - `dti.csv`
    - `loan_purpose.csv`
    - `employment_status.csv`
    - `employment_tenure.csv`
    - `loan_amount.csv`

    ## Interpretation
    Segment-level default rates are historical sample associations, not causal estimates. Small segments may have unstable rates. The 40% DTI split is an illustration for exploration, **not** a validated loan-approval rule.
    
