# Optional Power BI extension

The finished package includes an **interactive offline HTML dashboard**, not a `.pbix` file. A real PBIX requires authoring in Power BI Desktop and isn't falsely represented here.

To create a Power BI version with the original or synthetic files:
1. In Power BI Desktop choose **Get data → Text/CSV**, load `borrower_profiles.csv` and `loan_applications.csv` (or your original loan file).
2. In Model view connect `borrower_profiles[borrower_id]` (one) to `loan_applications[borrower_id]` (many), with single-direction filtering.
3. Create these measures in the **loan_applications** table:

```dax
Total Loans = COUNTROWS(loan_applications)
Total Defaults = CALCULATE(COUNTROWS(loan_applications), loan_applications[defaulted] = 1)
Default Rate = DIVIDE([Total Defaults], [Total Loans])
Average Loan Amount = AVERAGE(loan_applications[loan_amount])
```

4. Format Default Rate as a percentage.
5. Create visuals: cards for four KPIs, and charts by credit score band, loan purpose, employment status, and DTI band. The categories can be built with conditional columns in Power Query.
6. Do **not** publish confidential borrower-level data using **Publish to web**.
